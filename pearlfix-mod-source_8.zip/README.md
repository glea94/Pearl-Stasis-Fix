# Pearl Stasis Fix

Correctif Fabric provisoire pour un bug vanilla de Minecraft (26.1.2 / 26.2) qui fait
dupliquer/ressusciter les ender pearls en chambre de stase à chaque redémarrage du
serveur.

## Le bug

Depuis la 26.1.2, un bug reconnu par les développeurs de Paper
([Paper#13964](https://github.com/PaperMC/Paper/issues/13964)) fait que le serveur
conserve, dans les données du joueur, une référence vers chaque ender pearl en
"stase" (en vol suspendu, technique de téléportation différée). Cette référence
n'est jamais nettoyée quand la perle réelle est supprimée du monde - résultat, elle
est recréée à chaque reconnexion ou redémarrage, même après suppression manuelle.

Le mécanisme concerné est vanilla (`ServerPlayer.enderPearls`, un
`Set<ThrownEnderpearl>`), donc le bug touche aussi bien Paper que Fabric/vanilla.

## Le correctif

Un unique mixin (`ServerPlayerPearlMixin`) s'accroche à `ServerPlayer#tick()` et,
à chaque tick, retire du `Set` toute perle dont `Entity#isRemoved()` est vrai.
Une fois retirée, elle n'est plus sauvegardée dans les données du joueur et ne
peut donc plus être recréée au redémarrage suivant.

Le mod est **côté serveur uniquement** - inutile de l'installer côté client.

## C'est un correctif temporaire

Ce bug est reconnu et sera probablement corrigé officiellement par Mojang à un
moment donné. Désinstalle ce mod une fois que ce sera fait.

## Compiler

Prérequis : JDK 25.

```
./gradlew build
```

Le `.jar` compilé se trouve ensuite dans `build/libs/`.

## Installation

1. Fabric Loader 0.19.3 ou supérieur.
2. Dépose le `.jar` dans le dossier `mods/` du serveur.
3. Aucune configuration nécessaire.

## Licence

MIT - voir [LICENSE](LICENSE).
